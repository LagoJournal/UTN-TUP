# TP 7 – Herencia y Polimorfismo

Agustín Lago – Programación II (UTN TUP)

## Ejecutar

Abrir el proyecto en el IDE y ejecutar `App.java` (corre las 4 demos) o el `Demo.java` de cada paquete.

Por consola, desde la raíz:

```
javac -d out src/main/java/App.java src/main/java/Ejercicio*/*.java
java -cp out App
```
